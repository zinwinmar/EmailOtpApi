﻿namespace EmailOtpApi.Services
{
    public interface IOtpService
    {
        string GenerateOtp();
        void SaveOtp(string email, string otp);
        bool VerifyOtp(string email, string otp);
    }
}
