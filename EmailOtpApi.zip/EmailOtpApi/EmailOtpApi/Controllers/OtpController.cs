using EmailOtpApi.Models;
using EmailOtpApi.Services;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;

namespace EmailOtpApi.Controllers
{
    [ApiController]
    [Route("[api/otp]")]
    public class OtpController : ControllerBase
    {
        private readonly IOtpService _otpService;
        private readonly IEmailService _emailService;

        private readonly ILogger<OtpController> _logger;

        public OtpController(IOtpService otpService, IEmailService emailService)
        {
            _otpService = otpService;
            _emailService = emailService;
        }

        [HttpPost("Send")]
        public async Task<IActionResult> SendOtp([FromBody] OtpRequest request)
        {
            
            if(!IsValidEmail(request.Email) || !request.Email.EndsWith(".dso.org.sg"))
                     return BadRequest("Email status invalid");

            var otp = _otpService.GenerateOtp();
            _otpService.SaveOtp(request.Email, otp);
            
            await _emailService.SendEmailAsync(new EmailRequest
            {
                To = request.Email,
                Subject = "Your OTP Code",
                Body = $"Your OTP is: {otp}"
            });
            return Ok("OTP sent successfully");

        }

        [HttpPost("Verify")]
        public IActionResult VerifyOtp([FromBody] VerifyOtpRequest request)
        {
            var valid = _otpService.VerifyOtp(request.Email, request.Otp);

            if (!valid)
                return BadRequest("Invalid or expired OTP");

            return Ok("OTP verified successfully");
        }
        private bool IsValidEmail(string email)
        {
            var regex = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            return regex.IsMatch(email);
        }
    }
}
