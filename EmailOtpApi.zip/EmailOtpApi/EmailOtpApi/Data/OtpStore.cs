﻿namespace EmailOtpApi.Data
{
    public class OtpEntry
    { 
        public string Otp { get; set; }
        public DateTime Expiry { get; set; }
        public int Attempts { get; set; }
    }
    public class OtpStore
    {
        public static Dictionary<string, OtpEntry> Store = new Dictionary<string, OtpEntry>();
    }
}
