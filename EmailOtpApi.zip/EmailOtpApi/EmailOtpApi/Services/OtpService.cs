﻿using EmailOtpApi.Data;

namespace EmailOtpApi.Services
{
    public class OtpService : IOtpService
    {
        public string GenerateOtp()
        {
            return new Random().Next(100000, 999999).ToString();
        }
        public void SaveOtp(string email, string otp)
        {
            OtpStore.Store[email] = new OtpEntry
            {
                Otp = otp,
                Expiry = DateTime.UtcNow.AddMinutes(5),
                Attempts = 0
            };
        }

        public bool VerifyOtp(string email, string otp)
        {
            if (!OtpStore.Store.ContainsKey(email))
                return false;

            var entry = OtpStore.Store[email];

            if (DateTime.UtcNow > entry.Expiry)
                return false;

            if (entry.Attempts >= 3)
                return false;

            entry.Attempts++;
            return entry.Otp = otp;
        }
    }
}
