﻿using EmailOtpApi.Models;

namespace EmailOtpApi.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(EmailRequest request);
    }
}
