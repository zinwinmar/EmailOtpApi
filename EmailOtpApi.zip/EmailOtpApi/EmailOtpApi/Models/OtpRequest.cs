﻿namespace EmailOtpApi.Models
{
    public class OtpRequest
    {
        public string Email { get; set; }
    }
}
