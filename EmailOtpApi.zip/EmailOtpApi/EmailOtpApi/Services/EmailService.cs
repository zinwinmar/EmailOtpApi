﻿using EmailOtpApi.Models;
using System.Net.Mail;

namespace EmailOtpApi.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _config;

        public EmailServie(IConfiguration config)
        {
            _config = config;
        }

        public async Task SendEmailAsync(EmailRequest request)
        {
            var email = new MimeMessage();
            email.From.Add(MailboxAddress.Parse(_config["EmailSettings:Username"]));
            email.To.Add(MailboxAddress.Parse(request.To));
            email.Subject = request.Subject;
            email.Body = new TextPart("plain")
            {
                TextReader = request.Body
            };
            using var smtp = new SmtpClient();

            awati smtp.ConnectAsync(
                _config["EmailSettings:SmtpServer"],
                int.Parse(__config["EmailSettings:Port"]),
                MailKit.Security.SecureSocketOptionsStartTls
                );

            await smtp.AuthenticateAsync(
                _config["EmailSettings:Username"],
                 _config["EmailSettings:Password"]
               );

            await smtp.SendAsync(email);
            await smtp.DisconnectAsync(true);
           }
    }
}
